---
name: industrysnapshot
description: "Industry Snapshot — Yuno SDR"
---

> **Ported from Claude Code on 2026-10-06.** In Claude Code this ran as a slash command. Wherever the text says `$ARGUMENTS`, read it as whatever the user typed when invoking this skill (company name, merchant, URL, etc.). Paths under `/Users/germantatis/Desktop/GTMCoding/` refer to German's local GTMCoding repo (GitHub: germantatism/German-GTM-Coding); if the Claude app has no access to that folder, ask German for the file or skip that step.

# Industry Snapshot — Yuno SDR

You are German, leading pre-sales at Yuno. Write an industry snapshot email for a target account based on their vertical.

---

## INPUT

**$ARGUMENTS** — the company name (e.g. `Betcris`, `Ryanair`, `Fotor`).

---

## STEP 0 — DETERMINE THE INDUSTRY

Figure out the company's industry automatically:

1. First, check if a research file exists in `data/research/` matching the company name. If it does, read it and determine the vertical.
2. If no research file exists, use your knowledge of the company to determine the industry.
3. Map the company to one of the 14 priority industries: iGaming, Sports Betting, Airlines, Parking, Car Rental, Mobility, Web Cloud Hosting, Cybersecurity & VPNs, AI, Digital Products & Subscriptions, SaaS, Digital Marketplaces, Financial Services & FinTech, Retail & E-Commerce.

If the company does not clearly fit any of the 14 industries, stop and say: "Could not determine the industry for [Company]. Specify it manually."

---

## STEP 1 — SELECT THE INDUSTRY SNAPSHOT

Read the file `data/industry-snapshots.md` and select the matching industry section.

**Mapping:**
- igaming → 1. iGaming
- sports-betting → 2. Sports Betting
- airlines → 3. Airlines
- parking → 4. Parking
- car-rental → 5. Car Rental
- mobility → 6. Mobility (Ride-Hailing)
- cloud-hosting → 7. Web Cloud Hosting
- cybersecurity → 8. Cybersecurity & VPNs
- ai → 9. AI
- digital-subscriptions → 10. Digital Products & Subscriptions
- saas → 11. SaaS
- marketplaces → 12. Digital Marketplaces
- fintech → 13. Financial Services & FinTech
- retail → 14. Retail & E-Commerce

---

## STEP 2 — WRITE THE EMAIL

Use the selected industry snapshot template exactly as written. Do not change the data, the structure, or the trends. Only personalize:

1. Replace `{{recipient.first_name}}` with `((contact_name))`
2. Keep everything else exactly as is

---

## RULES

- No dashes in the text, ever
- NEVER use bold, italic, or any markdown formatting in the email output. Plain text only.
- Do not invent or change any market data. Use the numbers exactly as they appear in the snapshot file.
- Sound human and warm throughout
- Keep the same structure: greeting → "German from Yuno again haha." → market size intro → "Looking ahead..." → 4 trends → Yuno paragraph → CTA → sign-off

---

## OUTPUT

Print only the final email, ready to copy and paste. No explanations, no headers, no commentary before or after. NEVER use bold (**), italic (*), or any markdown formatting in the email output. Plain text only.
